close all; clear all; clc;
addpath(genpath(pwd));

%%%%% Read a video and extract frames
weight = []; % To store weights for convolution
fully_connected_weights = []; % To store weights for the fully connected layer
lstm_weights = []; % To store LSTM weights
previous_kernel = []; % Variable to hold previous frame's kernel

%  Specify the video file
video_file = ''; % Replace with your video file path

%  Create a VideoReader object
video = VideoReader(video_file);

% Initialize LSTM parameters
num_lstm_units = 20; % Number of LSTM units
time_steps = 10; % Number of time steps (sequence length for LSTM)
lstm_hidden_state = zeros(1, num_lstm_units); % Initial LSTM hidden state
lstm_cell_state = zeros(1, num_lstm_units); % Initial LSTM cell state

% Initialize storage for LSTM outputs
lstm_outputs = [];

% Step 3: Process each frame
frame_count = 0;
sequence_data = []; % To accumulate fully connected outputs as sequence input for LSTM

while hasFrame(video)
    % Read the current frame
    frame = readFrame(video);
    
    % Convert the image to grayscale if needed
    if size(frame, 3) == 3
        gray_frame = rgb2gray(frame);
    else
        gray_frame = frame;
    end
    
    % Normalize the image
    normalized_image = double(gray_frame) / 255; % Normalize to [0, 1]
    
    % Apply ReLU operation
    relu_image = max(0, normalized_image); % ReLU is max(0, x)
    
    % Apply convolution
    if isempty(previous_kernel)
        % For the first frame, generate a random kernel
        conv_kernel = rand(3, 3); % Random 3x3 kernel
    else
        % For subsequent frames, use the previous frame's kernel
        conv_kernel = previous_kernel;
    end
    
    % Perform convolution
    conv_output = conv2(relu_image, conv_kernel, 'same'); % Convolution operation
    
    % Apply dropout (simulated by zeroing out random pixels)
    dropout_rate = 0.3; % Dropout probability (30%)
    dropout_mask = rand(size(conv_output)) > dropout_rate;
    dropout_output = conv_output .* dropout_mask; % Element-wise masking
    
    % Apply softmax (across the entire frame for simplicity)
    exp_values = exp(dropout_output);
    softmax_output = exp_values ./ sum(exp_values(:)); % Softmax normalization
    
    % Fully connected layer
    if frame_count == 0
        fc_weights = rand(numel(softmax_output), 10); % Random weights for 10 output classes
    end
    fc_output = softmax_output(:)' * fc_weights; % Fully connected layer output
    
    % Store fully connected output for LSTM
    sequence_data = [sequence_data; fc_output]; % Accumulate outputs
    
    % Update previous kernel
    previous_kernel = conv_kernel; % Store current kernel for the next iteration
    
    % Increment frame counter
    frame_count = frame_count + 1;
    
    % Process accumulated data with LSTM if we reach the required time steps
    if mod(frame_count, time_steps) == 0
        % LSTM Layer Processing
        for t = 1:size(sequence_data, 1)
            % LSTM equations (simplified implementation)
            input_to_lstm = sequence_data(t, :);
            
            % Random LSTM weights (for demonstration)
            Wf = rand(size(input_to_lstm, 2), num_lstm_units); % Forget gate weights
            Wi = rand(size(input_to_lstm, 2), num_lstm_units); % Input gate weights
            Wo = rand(size(input_to_lstm, 2), num_lstm_units); % Output gate weights
            Wc = rand(size(input_to_lstm, 2), num_lstm_units); % Cell state weights
            
            bf = rand(1, num_lstm_units); % Forget gate bias
            bi = rand(1, num_lstm_units); % Input gate bias
            bo = rand(1, num_lstm_units); % Output gate bias
            bc = rand(1, num_lstm_units); % Cell state bias
            
            % Forget gate
            ft = sigmoid(input_to_lstm * Wf + bf);
            % Input gate
            it = sigmoid(input_to_lstm * Wi + bi);
            Ct_tilde = tanh(input_to_lstm * Wc + bc);
            % Cell state update
            lstm_cell_state = ft .* lstm_cell_state + it .* Ct_tilde;
            % Output gate
            ot = sigmoid(input_to_lstm * Wo + bo);
            % Hidden state update
            lstm_hidden_state = ot .* tanh(lstm_cell_state);
        end
        
        % Store LSTM output
        lstm_outputs = [lstm_outputs; lstm_hidden_state];
        
        % Clear sequence data for the next time step batch
        sequence_data = [];
    end
end

%  Display total number of frames processed
disp(['Total frames processed: ', num2str(frame_count)]);

%  Save weights and LSTM outputs
save('weights_and_lstm_outputs.mat', 'weight', 'fully_connected_weights', 'lstm_outputs');

% Sigmoid activation function
function output = sigmoid(x)
    output = 1 ./ (1 + exp(-x));
end
