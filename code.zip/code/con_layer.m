function conv_kernel=con_layer(relu_output)
    %  Define the convolution kernel
conv_kernel = [1 -1 0; -1 1 1; 0 1 -1]; % Example kernel
conv_output = conv2(relu_output, conv_kernel, 'same'); % Convolve with padding

%  Batch normalization
batch_mean = mean(conv_output(:));
batch_std = std(conv_output(:));
epsilon = 1e-5; % Small constant to avoid division by zero
batch_norm_output = (conv_output - batch_mean) / (batch_std + epsilon);

% Apply ReLU after batch normalization
relu2_output = max(0, batch_norm_output); % ReLU: max(0, x)

%  Max pooling
pool_size = 2; % Pool size for max pooling
[max_rows, max_cols] = size(relu2_output);
pooled_output = zeros(floor(max_rows/pool_size), floor(max_cols/pool_size));
for i = 1:pool_size:max_rows-pool_size+1
    for j = 1:pool_size:max_cols-pool_size+1
        pooled_output(ceil(i/pool_size), ceil(j/pool_size)) = max(max(relu2_output(i:i+pool_size-1, j:j+pool_size-1)));
    end
end
end